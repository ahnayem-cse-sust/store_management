<div class="row">
    <div class="col-md-12">
        <a id="window_cross_button" class="window_cross_button float-right" style="float:right" href="#" title="Cross">
            <img src="{{url('assets/images/cross.png')}}" style="width:30px;height:30px;margin-top:4px">
        </a>
        <a id="window_print_button" class="window_print_button float-right" style="float:right" href="#" title="Print" print-area=".printArea">
            <img src="{{url('assets/images/print.png')}}" style="width:50px;height:40px">
        </a>
    </div>
</div>