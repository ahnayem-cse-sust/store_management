<div class="card-header1">
    <table style="width:100%">
        <tbody>
            <tr>
                <td>
                    <p class="mb-1">
                        <img src="/assets/images/logo/voucher_header.png" style="width:100%" alt="" srcset="">
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
</div>