<table style="width:100%;" class="signature-table">
    <tbody>
        <td style="text-align:center;width:33%"> <span class="signature">تم الموافقة من قبل | Approved by</span></td>
        <td style="text-align:center;width:33%"><span class="signature">Accountant - محاسب </span></td>
        <td style="text-align:center;width:33%"><span class="signature">Receive By - المستلم</span></td>
    </tbody>
</table>