@extends('layouts.admin')
@section('content')

<div class="row row-sm justify-content-center">
    <div class="col-sm-8 col-lg-8 col-xl-8">
        <img src="/assets/images/dashboard.jpg" alt="" srcset="">
    </div><!-- col end -->
</div>
<!-- END ROW -->
@endsection
@section('scripts')
@parent
@endsection
